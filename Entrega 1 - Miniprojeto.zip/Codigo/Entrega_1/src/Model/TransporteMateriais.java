package Model;

public class TransporteMateriais extends Veiculo{
	private int pesoMax;
	private int distanciaTanque;
	private int noEixos;
	private boolean offRoad;
	
	public TransporteMateriais(int C, int CD, int P, String M, int PM, int DT, int NoE, boolean OF) {
		sCodigo(C);
		sCapacidadeDeposito(CD);
		sPeso(P);
		sModelo(M);
		pesoMax = PM;
		distanciaTanque = DT;
		noEixos = NoE;
		offRoad = OF;
	}
	
	public boolean oCalificado(Operador Op1) {
		boolean res = false;
		if(Op1.gCertificacao()>=2) {
			res = true;
		}
		return res;
	}
	
	public void asignarOperador(Operador Op1) {
		if (gOperador() == null) {
			if(oCalificado(Op1)==true) {
				if(Op1.gVeiculo()==false) {
					sOperador(Op1);
					Op1.aVeiculo();
					System.out.println("Operador cadastrado");
				}else {
					System.out.println("Operador ja tem veiculo");
				}
			}else {
				System.out.println("Operador nao e calificado");
			}
		}else {
			System.out.println("Veiculo ja tem operador");
		}
	}
	
	//GET/SET DISTANCIA TANQUE
	public int gDistanciaTanque() {
		return distanciaTanque;
	}
	public void sDistanciaTanque(int DT) {
		this.distanciaTanque = DT;
	}
	
	//GET/SET PESO MAX
	public int gPesoMax() {
		return pesoMax;
	}
	public void sPesoMax(int P) {
		this.pesoMax = P;
	}
	
	//GET/SET NO EIXOS
	public int gNoEixos() {
		return noEixos;
	}
	public void sNoEixos(int NoE) {
		this.noEixos = NoE;
	}
	
	//GET/CHANGE OFFROAD
	public boolean gOffroad() {
		return offRoad;
	}
	public void aOffroad() {
		if(this.offRoad == false) {
			this.offRoad = true;
		}else {
			this.offRoad = false;
		}
	}
}
