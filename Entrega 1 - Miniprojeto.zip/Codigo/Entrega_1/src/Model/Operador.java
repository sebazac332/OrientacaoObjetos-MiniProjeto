package Model;

public class Operador {
	private String cpf;
	private String nome;
	private int idade;
	private String cidade;
	private String endereco;
	private int certificacao;
	private boolean veiculo = false;
	
	public Operador(String CPF1,String N,int I,String Ci, String E, int C, boolean V) {
		cpf = CPF1;
		nome = N;
		idade = I;
		cidade = Ci;
		endereco  = E;
		certificacao = C;
		veiculo = V;
	}
	
	//GET/SET CPF
	public String gCPF() {
		return cpf;
	}
	public void sCPF(String C) {
		this.cpf = C;
	}
	
	//GET/SET NOME
	public String gNome() {
		return nome;
	}
	public void sNome(String Nom) {
		this.nome = Nom;
	}
	
	//GET/SET CIDADE
	public String gCidade() {
		return cidade;
	}
	public void sCidade(String Ci) {
		this.cidade = Ci;
	}
	
	//GET/SET IDADE
	public int gIdade() {
		return idade;
	}
	public void sIdade(int id) {
		this.idade = id;
	}
	
	//GET/SET ENDERECO
	public String gEndereco() {
		return endereco;
	}
	public void sEndereco(String En) {
		this.endereco = En;
	}
	
	//GET/CHANGE VEICULO
	public void aVeiculo() {
		if (this.veiculo == true) {
			this.veiculo = false;
		}else {
			this.veiculo = true;
		}
	}
	public boolean gVeiculo() {
		return veiculo;
	}
	
	//GET/SET CERTIFICACAO
	public void sCertificacao(int i) {
		this.certificacao = i;
	}
	public int gCertificacao() {
		return certificacao;
	}
}
