package Model;

public class MaquinasPesadas extends Veiculo{
	private int forcaHidraulica;
	private int pesoMaxlevantamento;
	private int alturaMaxlevantamento;

	public MaquinasPesadas(int C, int CD, int P, String M, int FH, int PML, int AML) {
		sCodigo(C);
		sCapacidadeDeposito(CD);
		sPeso(P);
		sModelo(M);
		forcaHidraulica = FH;
		pesoMaxlevantamento = PML;
		alturaMaxlevantamento = AML;
	}
	
	public boolean oCalificado(Operador Op1) {
		boolean res = false;
		if(Op1.gCertificacao()==3) {
			res = true;
		}
		return res;
	}
	
	public void asignarOperador(Operador Op1) {
		if (gOperador() == null) {
			if(oCalificado(Op1)==true) {
				if(Op1.gVeiculo()==false) {
					sOperador(Op1);
					Op1.aVeiculo();
					System.out.println("Operador cadastrado");
				}else {
					System.out.println("Operador ja tem veiculo");
				}
			}else {
				System.out.println("Operador nao e calificado");
			}
		}else {
			System.out.println("Veiculo ja tem operador");
		}
	}
	
	//GET/SET FORCA HIDRAULICA
	public int gForcaH(){
		return forcaHidraulica;
	}
	public void sForcaH(int FH){
		this.forcaHidraulica = FH;
	}
	
	//GET/SET PESO MAX LEVANTAMENTO
	public int gPesoML(){
		return pesoMaxlevantamento;
	}
	public void sPesoML(int PML){
		this.pesoMaxlevantamento = PML;
	}
	
	//GET/SET ALTURA MAX LEVANTAMENTO
	public int gAlturaML(){
		return alturaMaxlevantamento;
	}
	public void sAlturaML(int AML){
		this.alturaMaxlevantamento = AML; 
	}
}
