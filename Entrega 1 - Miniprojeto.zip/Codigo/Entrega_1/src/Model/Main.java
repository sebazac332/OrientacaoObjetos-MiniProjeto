package Model;

public class Main {
	static Operador O3;
	static Operador O2;
	static Operador O1;
	static Trabalho T1;
	static RequisitoA A1;
	static TransporteMateriais TM1;
	static RequisitoB B1;
	static MaquinasPesadas MP1;
	static RequisitoC C1;
	static TransportePessoas TP1;
	
	public static void main(String[] args) {
		O3 = new Operador("7332314456", "Jose Ramirez", 31, "Passos", "Rua dos Pedreiros 1739", 3, false);
		O2 = new Operador("7245364786", "Gabriela Gomes ", 28, "Porto Alegre", "Beco Nove 7", 2, false);
		O1 = new Operador("7134879466", "Simão Esteves", 25, "Salvador", "Travessa Nova Era 1091", 1, false);
		
		T1 = new Trabalho(01, "Queimados", "Rodovia Rio-São Paulo 454", "Cavar um buraco no chão", false);
		
		A1 = new RequisitoA(02, 153, false);
		TM1 = new TransporteMateriais(01, 132, 134, "CAT-123", 280, 1500, 3, true);
		TM1.asignarOperador(O1);
		TM1.asignarOperador(O2);
		A1.asignarVeiculo(TM1);
		TM1.sPesoMax(500);
		A1.asignarVeiculo(TM1);
		A1.setCodigoT(T1);
		
		B1 = new RequisitoB(03,167, 300, 400);
		MP1 = new MaquinasPesadas(01, 200, 340, "CAT-332", 120, 400, 410);
		MP1.asignarOperador(O1);
		MP1.asignarOperador(O2);
		MP1.asignarOperador(O3);
		B1.asignarVeiculo(MP1);
		MP1.sForcaH(180);
		B1.asignarVeiculo(MP1);
		B1.setCodigoT(T1);
		
		C1 = new RequisitoC(04,34, 1500);
		TP1 = new TransportePessoas(01, 250, 150, "Setra A", 30, 1600, 2);
		TP1.asignarOperador(O1);
		C1.asignarVeiculo(TP1);
		TP1.sNoMaxPessoas(35);
		C1.asignarVeiculo(TP1);
		B1.setCodigoT(T1);
		
		System.out.println("\n");
		System.out.println("Trabalho 1");
		System.out.println(T1.gCodigo());
		System.out.println(T1.gCidade());
		System.out.println(T1.gDescripcao());
		System.out.println(T1.gEndereco());
		System.out.println(T1.gConcluido());
		
		System.out.println("\n");
		System.out.println("Operador 3");
		System.out.println(O3.gCPF());
		System.out.println(O3.gNome());
		System.out.println(O3.gIdade());
		System.out.println(O3.gCidade());
		System.out.println(O3.gEndereco());
		System.out.println(O3.gVeiculo());
		
		System.out.println("\n");
		System.out.println("Operador 2");
		System.out.println(O2.gCPF());
		System.out.println(O2.gNome());
		System.out.println(O2.gIdade());
		System.out.println(O2.gCidade());
		System.out.println(O2.gEndereco());
		System.out.println(O2.gVeiculo());
		
		System.out.println("\n");
		System.out.println("Operador 3");
		System.out.println(O3.gCPF());
		System.out.println(O3.gNome());
		System.out.println(O3.gIdade());
		System.out.println(O3.gCidade());
		System.out.println(O3.gEndereco());
		System.out.println(O3.gVeiculo());
		
		System.out.println("\n");
		System.out.println("Transporte de Materiais");
		System.out.println(TM1.gCodigo());
		System.out.println(TM1.gModelo());
		System.out.println(TM1.gPeso());
		System.out.println(TM1.gCapacidadeDeposito());
		System.out.println(TM1.gDisponibilidade());
		System.out.println(TM1.gPesoMax());
		System.out.println(TM1.gNoEixos());
		System.out.println(TM1.gDistanciaTanque());
		System.out.println(TM1.gOffroad());
		
		System.out.println("\n");
		System.out.println("Maquinaria Pesada");
		System.out.println(MP1.gCodigo());
		System.out.println(MP1.gModelo());
		System.out.println(MP1.gPeso());
		System.out.println(MP1.gCapacidadeDeposito());
		System.out.println(MP1.gDisponibilidade());
		System.out.println(MP1.gAlturaML());
		System.out.println(MP1.gForcaH());
		System.out.println(MP1.gPesoML());
		
		System.out.println("\n");
		System.out.println("Transporte pessoas");
		System.out.println(TP1.gCodigo());
		System.out.println(TP1.gModelo());
		System.out.println(TP1.gPeso());
		System.out.println(TP1.gCapacidadeDeposito());
		System.out.println(TP1.gDisponibilidade());
		System.out.println(TP1.gNoEixos());
		System.out.println(TP1.gNoMaxPessoas());
		System.out.println(TP1.gDistanciaT());
		
		System.out.println("\n");
		System.out.println("Requisito A");
		System.out.println(A1.gCodigoRV());
		System.out.println(A1.gCodigoR());
		System.out.println(A1.gCodigoT());
		System.out.println(A1.gOcupado());
		System.out.println(A1.gPesoT());
		System.out.println(A1.GSoC());
		
		System.out.println("\n");
		System.out.println("Requisito B");
		System.out.println(B1.gCodigoRV());
		System.out.println(B1.gCodigoR());
		System.out.println(B1.gCodigoT());
		System.out.println(B1.gOcupado());
		System.out.println(B1.gFuerzaR());
		System.out.println(B1.gPesoM());
		System.out.println(B1.gAlturaL());
		
		System.out.println("\n");
		System.out.println("Requisito C");
		System.out.println(C1.gCodigoRV());
		System.out.println(C1.gCodigoR());
		System.out.println(C1.gCodigoT());
		System.out.println(C1.gOcupado());
		System.out.println(C1.gNoPessoasM());
		System.out.println(C1.gDistancia());
		
		System.out.println("\n");
		MP1.eliminarOperador(O3);
		System.out.println(MP1.gOperador());
		
		System.out.println("\n");
		B1.eliminarVeiculo(MP1);
		System.out.println(B1.gCodigoR());
		System.out.println(B1.gOcupado());
		
		System.out.println("\n");
		T1.aConcluido();
		System.out.println(T1.gConcluido());
	}
}
