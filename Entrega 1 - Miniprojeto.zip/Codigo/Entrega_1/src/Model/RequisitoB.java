package Model;

public class RequisitoB extends RequisitoVehiculo{
	private int fuerzaRequerida;
	private int alturaL;
	private int pesoMinCarga;
	
	public RequisitoB(int RV, int FR, int AL, int PMC) {
		setCodigoRV(RV);
		fuerzaRequerida = FR;
		alturaL = AL;
		pesoMinCarga = PMC;
	}
	
	public void asignarVeiculo(MaquinasPesadas V2) {
		if(gOcupado()==false) {
			if (requisitoVehiculo(V2) == true) {
				setCodigoR(V2);	
				cambiarOcupado();
				System.out.println("Maquina pesada cadastrado");
			}else {
				System.out.println("Maquina pesada nao conforme com os requisitos");
			}
		}else {
			System.out.println("Ja tem maquina pesada");
		}
	}
	
	public boolean requisitoVehiculo(MaquinasPesadas V2) {
		boolean res = false;
		if(fuerzaRequerida <= V2.gForcaH() && alturaL <= V2.gAlturaML() && pesoMinCarga <= V2.gPesoML()) {
			res = true;
		}
		return res;
	}
	
	public void eliminarVeiculo(MaquinasPesadas V2) {
		if(gOcupado()==true) {
			eliminarCodigo();
			cambiarOcupado();
			V2.cambiarDisponibilidade();
			System.out.println("Maquina pesada eliminado");
		}else {
			System.out.println("Nao tem maquina pesada asignado");
		}
	}
	
	//GET/SET FUERZA REQUERIDA
	public int gFuerzaR() {
		return fuerzaRequerida;
	}
	public void sFuerzaR(int FH) {
		this.fuerzaRequerida = FH;
	}
	
	//GET/SET ALTURA LEVANTAMENTO
	public int gAlturaL() {
		return alturaL;
	}
	public void sAlturaL(int AL) {
		this.alturaL = AL;
	}
	
	//GET/SET PESO MIN LEVANTAMENTO
	public int gPesoM() {
		return pesoMinCarga;
	}
	public void sPesoM(int PM) {
		this.pesoMinCarga = PM;
	}
}
