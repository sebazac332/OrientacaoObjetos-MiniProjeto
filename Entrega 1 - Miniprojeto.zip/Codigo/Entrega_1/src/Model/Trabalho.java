package Model;

public class Trabalho {
	private int codigo;
	private String cidade;
	private String endereco;
	private String descripcao;
	private boolean concluido;
	
	//GET/SET CODIGO
	public int gCodigo() {
		return codigo;
	}
	public void sCodigo(int Cod) {
		this.codigo = Cod;
	}
	
	//GET/SET CIDADE
	public String gCidade() {
		return cidade;
	}
	public void sCidade(String Cid) {
		this.cidade = Cid;
	}
	
	//GET/SET ENDERECO
	public String gEndereco() {
		return endereco;
	}
	public void sEndereco(String En) {
		this.endereco = En;
	}
	
	//GET/SET DESCRIPCAO
	public String gDescripcao() {
		return descripcao;
	}
	public void sDescripcao(String Des) {
		this.descripcao = Des;
	}
	
	//GET/CHANGE CONCLUIDO
	public boolean gConcluido() {
		return concluido;
	}
	public void aConcluido() {
		if(this.concluido == true) {
			this.concluido = false;
		}else {
			this.concluido = true;
		}
	}
	
	public Trabalho(int C, String Ci, String En, String D, boolean Co) {
		codigo = C;
		cidade = Ci;
		endereco = En;
		descripcao = D;
		concluido = Co;
	}
}
