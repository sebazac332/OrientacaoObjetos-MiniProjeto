package Model;

public abstract class RequisitoVehiculo {
	private int codigoRV;
	private int codigoR;
	private int codigoT;
	private boolean ocupado;
	
	public void asignarVeiculo(Veiculo V1) {
		if (requisitoVehiculo(V1) == true) {
			this.codigoR = V1.gCodigo();	
			V1.cambiarDisponibilidade();
		}else {
			System.out.println("Veículo nao conforme com os requisitos");
		}
	}
	public boolean requisitoVehiculo(Veiculo V1) {
		boolean ans = false;
		return ans;
	}
	
	public void eliminarVeiculo(Veiculo V1) {
		if(gOcupado()==true) {
			eliminarCodigo();
			cambiarOcupado();
			V1.cambiarDisponibilidade();
			System.out.println("Veiculo eliminado");
		}else {
			System.out.println("Nao tem veiculo");
		}
	}
	
	//GET/SET Codigo RV
	public int gCodigoRV() {
		return codigoRV;
	}
	public void setCodigoRV(int RV1) {
		this.codigoR = RV1;
	}
	
	//GET/SET CODIGOR
	public int gCodigoR() {
		return codigoR;
	}
	public void setCodigoR(Veiculo V1) {
		this.codigoR = V1.gCodigo();
	}
	
	public void eliminarCodigo() {
		this.codigoR = 0;
	}
	
	//GET/SET CODIGOT
	public int gCodigoT() {
		return codigoT;
	}
	public void setCodigoT(Trabalho T1) {
		this.codigoT = T1.gCodigo();
	}
	
	//GET/CHANGE OCUPADO
	public boolean gOcupado() {
		return ocupado;
	}
	
	public void cambiarOcupado() {
		if (this.ocupado == false) {
			this.ocupado = true;
		}else {
			this.ocupado = false;
		}
	}
	
}
