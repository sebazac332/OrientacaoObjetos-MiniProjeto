package Model;

public abstract class Veiculo {
	private int codigo;
	private int capacidadeDeposito;
	private boolean disponivel = true;
	private int peso;
	private String modelo;
	private Operador op = null;
	
	public void asignarOperador(Operador Op1) {
		if (this.op == null) {
			if(Op1.gVeiculo()==false) {
				this.op = Op1;
				Op1.aVeiculo();
			}else {
				System.out.println("Operador ja tem veiculo");
			}
		}else {
			System.out.println("Veiculo ja tem operador");
		}
	}
	
	public void eliminarOperador(Operador Op1) {
		if(this.op != null) {
			this.op = null;
			Op1.aVeiculo();
			System.out.println("Operador eliminado");
		}else {
			System.out.println("Veiculo ainda nao tem operador");
		}
	}
	
	public boolean oCalificado(Operador Op1) {
		boolean res = false;
		return res;
	}
	
	//GET/CHANGE DISPONIBILIDADE
	public boolean gDisponibilidade() {
		return disponivel;
	}
	public void cambiarDisponibilidade() {
		if (this.disponivel == true) {
			this.disponivel = false;
		}else {
			this.disponivel = true;
		}
	}
	
	//GET/SET CODIGO
	public int gCodigo() {
		return codigo;
	}
	public void sCodigo(int C) {
		this.codigo = C;
	}
	
	//GET/SET MODELO
	public String gModelo() {
		return modelo;
	}
	public void sModelo(String M){
		this.modelo = M;
	}
	
	//GET/SET CapacidadeDeposito
	public int gCapacidadeDeposito() {
		return capacidadeDeposito;
	}
	public void sCapacidadeDeposito(int CapD){
		this.capacidadeDeposito = CapD;
	}
	
	//GET/SET Peso
	public int gPeso() {
		return peso;
	}
	public void sPeso(int P){
		this.peso = P;
	}
	
	//GET/SET OPERADOR
	public Operador gOperador() {
		return op;
	}
	public void sOperador(Operador OP1) {
		this.op = OP1;
	}
}
