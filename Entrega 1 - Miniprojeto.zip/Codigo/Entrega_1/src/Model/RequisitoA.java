package Model;

public class RequisitoA extends RequisitoVehiculo{
	private int pesoTotal;
	private boolean soCarretera;
	
	public RequisitoA(int RV, int PT, boolean SC) {
		setCodigoRV(RV);
		pesoTotal = PT;
		soCarretera = SC;
	}
	
	public void asignarVeiculo(TransporteMateriais V1) {
		if(gOcupado()==false) {
			if (requisitoVehiculo(V1) == true) {
				setCodigoR(V1);	
				cambiarOcupado();
				System.out.println("Veículo de transporte de materiais cadastrado");
			}else {
				System.out.println("Veículo de transporte de materiais nao conforme com os requisitos");
			}
		}else {
			System.out.println("Ja tem veículo de transporte de materiais");
		}
	}
	
	public boolean requisitoVehiculo(TransporteMateriais V1) {
		boolean res = false;
		if(soCarretera==false) {
			if(V1.gOffroad()==true && (pesoTotal + V1.gPeso())<= V1.gPesoMax()) {
				res = true;
			}
		}else {
			if((pesoTotal + V1.gPeso())<= V1.gPesoMax()) {
				res = true;
			}	
		}
		return res;
	}
	
	public void eliminarVeiculo(TransporteMateriais V1) {
		if(gOcupado()==true) {
			eliminarCodigo();
			cambiarOcupado();
			V1.cambiarDisponibilidade();
			System.out.println("Veículo de transporte eliminado");
		}else {
			System.out.println("Nao tem veículo de transporte de materiais asignado");
		}
	}
	
	//GET/SET Peso Total
	public int gPesoT() {
		return pesoTotal;
	}
	public void sPesoT(int PT) {
		this.pesoTotal = PT;
	}
	
	//GET/SET SO CARRETERA
	public boolean GSoC() {
		return soCarretera;
	}
	public void SSoC(boolean S) {
		this.soCarretera = S;
	}
	
}
