package Model;

public class TransportePessoas extends Veiculo{
	private int noMaxPessoas;
	private int distanciaTanque;
	private int noEixos;
	
	public TransportePessoas(int C, int CD, int P, String M, int NMP, int DT, int NoE) {
		sCodigo(C);
		sCapacidadeDeposito(CD);
		sPeso(P);
		sModelo(M);
		noMaxPessoas = NMP;
		distanciaTanque = DT;
		noEixos = NoE;
	}
	
	public boolean oCalificado(Operador Op1) {
		boolean res = false;
		if(Op1.gCertificacao()>=1) {
			res = true;
		}
		return res;
	}
	
	public void asignarOperador(Operador Op1) {
		if (gOperador() == null) {
			if(oCalificado(Op1)==true) {
				if(Op1.gVeiculo()==false) {
					sOperador(Op1);
					Op1.aVeiculo();
					System.out.println("Operador cadastrado");
				}else {
					System.out.println("Operador ja tem veiculo");
				}
			}else {
				System.out.println("Operador nao e calificado");
			}
		}else {
			System.out.println("Veiculo ja tem operador");
		}
	}
	
	//GET/SET NO MAXIMO PESSOAS
	public int gNoMaxPessoas() {
		return noMaxPessoas;
	}
	public void sNoMaxPessoas(int NMP) {
		this.noMaxPessoas = NMP;
	}
	
	//GET/SET DISTANCIA TANQUE
	public int gDistanciaT() {
		return distanciaTanque;
	}
	public void sDistanciaT(int DT) {
		this.distanciaTanque = DT;
	}
	
	//GET/SET NO EIXOS	
	public int gNoEixos() {
		return noEixos;
	}
	public void sNoEixos(int NoE) {
		this.noEixos = NoE;
	}
}
