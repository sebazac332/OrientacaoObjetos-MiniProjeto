package Model;

public class RequisitoC extends RequisitoVehiculo{
	private int noPessoas;
	private int distancia;
	
	public RequisitoC(int RV, int NoP, int Dist) {
		setCodigoRV(RV);
		noPessoas = NoP;
		distancia = Dist;
	}
	
	public void asignarVeiculo(TransportePessoas V3) {
		if(gOcupado()==false) {
			if (requisitoVehiculo(V3) == true) {
				setCodigoR(V3);	
				cambiarOcupado();
				System.out.println("Veículo de transporte de pessoas cadastrado");
			}else {
				System.out.println("Veículo de transporte de pessoas nao conforme com os requisitos");
			}
		}else {
			System.out.println("Ja tem veículo de transporte de pessoas");
		}
	}
	
	public boolean requisitoVehiculo(TransportePessoas V3) {
		boolean res = false;
		if(noPessoas <= V3.gNoMaxPessoas() && distancia <= V3.gDistanciaT()) {
			res = true;
		}
		return res;
	}
	
	public void eliminarVeiculo(TransportePessoas V3) {
		if(gOcupado()==true) {
			eliminarCodigo();
			cambiarOcupado();
			V3.cambiarDisponibilidade();
			System.out.println("Veículo de transporte de pessoas eliminado");
		}else {
			System.out.println("Nao tem veículo de transporte de pessoas asignado");
		}
	}
	
	//GET/SET NO PESSOAS
	public int gNoPessoasM() {
		return noPessoas;
	}
	public void sNoPessoasM(int NP) {
		this.noPessoas = NP;
	}
	
	//GET/SET DISTANCIA
	public int gDistancia() {
		return distancia;
	}
	public void sDistancia(int D) {
		this.distancia = D;
	}
}
